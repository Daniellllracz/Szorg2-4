﻿using System;
using System.IO; // Ezt mindenképp add hozzá, ez kell a fájlkezeléshez!
using System.Text;
using System.Windows;

namespace SzorgalmiWPF
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"../../../src/szorg2.txt");

                if (File.Exists(filePath))
                {

                    string[] lines = File.ReadAllLines(filePath, Encoding.UTF8);

                    if (lines.Length > 0)
                    {

                        Random rnd = new Random();
                        int randomIndex = rnd.Next(lines.Length); 

                        string selectedLine = lines[randomIndex];


                        EredmenyTextBlock.Text = selectedLine;
                    }
                    else
                    {
                        MessageBox.Show("A fájl üres!");
                    }
                }
                else
                {
                    MessageBox.Show("Nem található a fájl! Ellenőrizd a 'Copy to Output' beállítást.");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Hiba történt: " + ex.Message);
            }
        }
    }
}